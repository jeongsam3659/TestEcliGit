package kr.co.campus.beans;

public class TestBean {
	
	private int data1;
	private double data2;
	private boolean data3;
	private String data4;
	private DataBean databean5;
	private DataBean data6;

	public int getData1() {
		return data1;
	}

	public void setData1(int data1) {
		this.data1 = data1;
	}
	
	public double getData2() {
		return data2;
	}

	public void setData2(double data2) {
		this.data2 = data2;
	}

	public boolean isData3() {
		return data3;
	}

	public void setData3(boolean data3) {
		this.data3 = data3;
	}

	public String getData4() {
		return data4;
	}

	public void setData4(String data4) {
		this.data4 = data4;
	}
	
	public DataBean getDatabean5() {
		return databean5;
	}

	public void setDatabean5(DataBean databean5) {
		this.databean5 = databean5;
	}

	public DataBean getData6() {
		return data6;
	}

	public void setData6(DataBean data6) {
		this.data6 = data6;
	}

	
	
}
