package kr.co.campus.beans;

public class TestBean2 {
	
	public TestBean2() {
		System.out.println("TestBean2 �� ������");
	}
	
	public void default_init() {
		System.out.println("TestBean2�� default_init");
	}
	
	public void default_destory() {
		System.out.println("TestBean2�� default_destory");
	}
}
