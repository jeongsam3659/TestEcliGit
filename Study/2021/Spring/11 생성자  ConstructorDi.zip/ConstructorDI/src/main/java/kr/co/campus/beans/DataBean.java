package kr.co.campus.beans;

public class DataBean {
	
}
