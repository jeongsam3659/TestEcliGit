package kr.co.campus.beans;

public class HellowWorldEn {

	public void sayHello() {
		System.out.println("�ȳ��ϼ���.");
	}
}
