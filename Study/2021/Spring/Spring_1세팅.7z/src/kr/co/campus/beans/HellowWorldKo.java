package kr.co.campus.beans;

public class HellowWorldKo {
	public void sayHello() {
		System.out.println("�ȳ��ϼ��� 2222");
	}
}
